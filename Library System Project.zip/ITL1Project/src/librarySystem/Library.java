package librarySystem;

import java.util.ArrayList;
import java.util.List;

public class Library {
    private List<Book> books;
    private List<User> users;

    public Library() {
        books = new ArrayList<>();
        users = new ArrayList<>();
    }

    public void addUser(String userName) {
        User user = new User(userName);
        users.add(user);
    }

    public void addBook(String name, String author) {
        Book book = new Book(name, author);
        books.add(book);
    }

    public void issueBook(String bookName, String userName, String date) {
        for (Book book : books) {
            if (book.getName().equals(bookName) && book.getIssuedTo() == null) {
                book.issueBook(userName, date);
                return;
            }
        }
        System.out.println("Book not found or already issued.");
    }

    public void returnBook(String bookName) {
        for (Book book : books) {
            if (book.getName().equals(bookName) && book.getIssuedTo() != null) {
                book.returnBook();
                return;
            }
        }
        System.out.println("Book not found or not issued.");
    }

    public void displayBooks() {
        for (Book book : books) {
            System.out.println("Book Name: " + book.getName());
            System.out.println("Book Author: " + book.getAuthor());
            System.out.println("Issued To: " + (book.getIssuedTo() != null ? book.getIssuedTo() : "Not Issued"));
            System.out.println("Issued On: " + (book.getIssuedOn() != null ? book.getIssuedOn() : "N/A"));
            System.out.println("------------");
        }
    }
}