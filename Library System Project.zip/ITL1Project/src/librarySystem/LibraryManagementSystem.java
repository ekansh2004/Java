package librarySystem;

import java.util.Scanner;

public class LibraryManagementSystem {
    public static void main(String[] args) {
        Library library = new Library();
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("Library Management System Menu:");
            System.out.println("1. Add User");
            System.out.println("2. Add Book");
            System.out.println("3. Issue Book");
            System.out.println("4. Return Book");
            System.out.println("5. Display Books");
            System.out.println("6. Exit");

            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); 

            switch (choice) {
                case 1:
                    System.out.print("Enter User Name: ");
                    String userName = scanner.nextLine();
                    library.addUser(userName);
                    System.out.println("User added successfully.");
                    break;

                case 2:
                    System.out.print("Enter Book Name: ");
                    String bookName = scanner.nextLine();
                    System.out.print("Enter Book Author: ");
                    String author = scanner.nextLine();
                    library.addBook(bookName, author);
                    System.out.println("Book added successfully.");
                    break;

                case 3:
                    System.out.print("Enter Book Name to Issue: ");
                    bookName = scanner.nextLine();
                    System.out.print("Enter User Name: ");
                    userName = scanner.nextLine();
                    System.out.print("Enter Issued Date: ");
                    String issuedDate = scanner.nextLine();
                    library.issueBook(bookName, userName, issuedDate);
                    break;

                case 4:
                    System.out.print("Enter Book Name to Return: ");
                    bookName = scanner.nextLine();
                    library.returnBook(bookName);
                    break;

                case 5:
                    library.displayBooks();
                    break;

                case 6:
                    System.out.println("Goodbye!");
                    scanner.close();
                    System.exit(0);

                default:
                    System.out.println("Invalid choice. Please try again.");
                    break;
            }
        }
    }
}