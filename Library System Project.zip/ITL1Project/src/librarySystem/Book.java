package librarySystem;

public class Book {
    private String name;
    private String author;
    private String issuedTo;
    private String issuedOn;

    public Book(String name, String author) {
        this.name = name;
        this.author = author;
    }

    public String getName() {
        return name;
    }

    public String getAuthor() {
        return author;
    }

    public String getIssuedTo() {
        return issuedTo;
    }

    public String getIssuedOn() {
        return issuedOn;
    }

    public void issueBook(String userName, String date) {
        this.issuedTo = userName;
        this.issuedOn = date;
    }

    public void returnBook() {
        this.issuedTo = null;
        this.issuedOn = null;
    }
}